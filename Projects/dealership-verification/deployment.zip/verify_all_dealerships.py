#!/usr/bin/env python3

import pandas as pd
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import time
from datetime import datetime
import os
import sys
import argparse
from fuzzywuzzy import process, fuzz
import logging
import json
import re
from typing import Dict, Any, List, Tuple
from urllib.parse import urlparse

# Import Selenium and BeautifulSoup for contact scraping
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from webdriver_manager.chrome import ChromeDriverManager
    from bs4 import BeautifulSoup
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    logging.warning("Selenium and/or BeautifulSoup not installed. Contact scraping will be disabled.")
    logging.warning("Install with: pip install selenium webdriver-manager beautifulsoup4")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('dealership_verification.log'),
        logging.StreamHandler()
    ]
)

# Mapping dictionaries for standardization
STATE_MAPPING = {
    'ALABAMA': 'AL', 'ALASKA': 'AK', 'ARIZONA': 'AZ', 'ARKANSAS': 'AR',
    'CALIFORNIA': 'CA', 'COLORADO': 'CO', 'CONNECTICUT': 'CT', 'DELAWARE': 'DE',
    'FLORIDA': 'FL', 'GEORGIA': 'GA', 'HAWAII': 'HI', 'IDAHO': 'ID',
    'ILLINOIS': 'IL', 'INDIANA': 'IN', 'IOWA': 'IA', 'KANSAS': 'KS',
    'KENTUCKY': 'KY', 'LOUISIANA': 'LA', 'MAINE': 'ME', 'MARYLAND': 'MD',
    'MASSACHUSETTS': 'MA', 'MICHIGAN': 'MI', 'MINNESOTA': 'MN', 'MISSISSIPPI': 'MS',
    'MISSOURI': 'MO', 'MONTANA': 'MT', 'NEBRASKA': 'NE', 'NEVADA': 'NV',
    'NEW HAMPSHIRE': 'NH', 'NEW JERSEY': 'NJ', 'NEW MEXICO': 'NM', 'NEW YORK': 'NY',
    'NORTH CAROLINA': 'NC', 'NORTH DAKOTA': 'ND', 'OHIO': 'OH', 'OKLAHOMA': 'OK',
    'OREGON': 'OR', 'PENNSYLVANIA': 'PA', 'RHODE ISLAND': 'RI', 'SOUTH CAROLINA': 'SC',
    'SOUTH DAKOTA': 'SD', 'TENNESSEE': 'TN', 'TEXAS': 'TX', 'UTAH': 'UT',
    'VERMONT': 'VT', 'VIRGINIA': 'VA', 'WASHINGTON': 'WA', 'WEST VIRGINIA': 'WV',
    'WISCONSIN': 'WI', 'WYOMING': 'WY', 'DISTRICT OF COLUMBIA': 'DC'
}

CAR_BRAND_ABBREVIATIONS = {
    'Gmc': 'GMC',
    'Bmw': 'BMW',
    'Vw': 'VW',
    'Mercedes Benz': 'Mercedes-Benz',
    'Kia Motors': 'KIA',
    'Gm': 'GM',
    'Buik': 'Buick',
    'Cadilac': 'Cadillac',
    'Chevrolet': 'Chevy',
    'Chrysler Dodge Jeep Ram': 'CDJR',
    'Chrysler Dodge Jeep': 'CDJ',
}

# Staff page related constants
STAFF_PAGE_KEYWORDS = [
    "meet the team",
    "our team", 
    "meet our team",
    "staff",
    "team",
    "leadership",
    "executive team",
    "management team",
    "dealership team",
    "about us",
    "contact us"
]

# Define automotive leadership titles by category
EXECUTIVE_TITLES = {
    "Executive Level": [
        "ceo", "chief executive officer",
        "coo", "chief operating officer",
        "cmo", "chief marketing officer",
        "president", "vice president", "vp",
        "owner", "dealer principal", "managing partner", "partner",
        "founder", "chief", "executive"
    ],
    "Dealership Management": [
        "general manager", "gm",
        "platform general manager",
        "executive manager",
        "general sales manager",
        "executive gm",
        "dealer operator"
    ],
    "Department Directors": [
        "bdc director", "bdc manager",
        "service director", "service manager",
        "fixed operations director", "fixed operations manager",
        "internet director",
        "marketing director", "marketing manager",
        "director", "managing director",
        "sales director"
    ]
}

class DealershipVerifier:
    def __init__(self, input_file, batch_size=50, max_workers=4, save_interval=50):
        self.input_file = input_file
        self.batch_size = batch_size
        self.max_workers = max_workers
        self.save_interval = save_interval
        
        # Initialize Chrome options for headless operation
        self.chrome_options = Options()
        self.chrome_options.add_argument('--headless')
        self.chrome_options.add_argument('--no-sandbox')
        self.chrome_options.add_argument('--disable-dev-shm-usage')
        
        # Set up file paths
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.results_dir = os.path.join(self.base_dir, 'results')
        os.makedirs(self.results_dir, exist_ok=True)
        
        # Load manufacturer data
        self.manufacturer_data = {
            "Toyota": ["toyota", "lexus"],
            "Ford": ["ford", "lincoln"],
            "GM": ["chevrolet", "chevy", "gmc", "buick", "cadillac"],
            "Honda": ["honda", "acura"],
            "BMW": ["bmw", "mini"],
            "Mercedes": ["mercedes", "benz"],
            "Hyundai": ["hyundai", "genesis"],
            "Kia": ["kia"],
            "Stellantis": ["chrysler", "dodge", "jeep", "ram", "fiat"],
            "VW": ["volkswagen", "vw", "audi", "porsche"],
            "Nissan": ["nissan", "infiniti"],
            "Mazda": ["mazda"],
            "Subaru": ["subaru"],
            "Volvo": ["volvo"],
            "Jaguar Land Rover": ["jaguar", "land rover"],
            "Tesla": ["tesla"]
        }
        
        # Initialize progress tracking
        self.total_processed = 0
        self.active_websites = 0
        self.manufacturer_counts = {}
        
        # Load existing progress if available
        self.job_id = None
        self.load_progress()

    def load_progress(self):
        """Load existing progress if available."""
        try:
            with open('progress.json', 'r') as f:
                progress = json.load(f)
                self.total_processed = progress.get('total_processed', 0)
                self.active_websites = progress.get('active_websites', 0)
                self.manufacturer_counts = progress.get('manufacturer_counts', {})
                self.job_id = progress.get('job_id')
        except FileNotFoundError:
            pass

    def save_progress(self):
        """Save current progress to file."""
        progress = {
            'total_processed': self.total_processed,
            'active_websites': self.active_websites,
            'manufacturer_counts': self.manufacturer_counts,
            'job_id': self.job_id
        }
        with open('progress.json', 'w') as f:
            json.dump(progress, f)

    def clean_url(self, url):
        """Clean and standardize URL format."""
        if not url or pd.isna(url):
            return ""
        
        url = str(url).strip().lower()
        if not url.startswith(('http://', 'https://')):
            url = f'https://{url}'
        
        return url

    def verify_url(self, url):
        """Verify if a URL is active and accessible."""
        if not url or pd.isna(url):
            return False, None

        max_retries = 3
        retry_delay = 2
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        for attempt in range(max_retries):
            try:
                url = self.clean_url(url)
                response = requests.head(url, headers=headers, allow_redirects=True, timeout=10)
                
                # Check if redirected to a login page or error page
                if any(x in response.url.lower() for x in ['login', 'error', '404', 'not-found']):
                    logging.debug(f"URL {url} redirected to login/error page")
                    return False, response.url
                
                return response.status_code == 200, response.url
            
            except requests.RequestException as e:
                logging.debug(f"Attempt {attempt + 1} failed for {url}: {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay * (attempt + 1))  # Exponential backoff
                continue
        
        return False, None

    def identify_manufacturer(self, row):
        """Identify the manufacturer based on dealership name and URL."""
        name = str(row['DealershipName']).lower()
        url = str(row['Website']).lower()
        
        # First check for direct matches
        for manufacturer, keywords in self.manufacturer_data.items():
            if any(keyword in name or keyword in url for keyword in keywords):
                return manufacturer
        
        # If no direct match, use fuzzy matching
        best_match = None
        highest_ratio = 0
        
        for manufacturer, keywords in self.manufacturer_data.items():
            for keyword in keywords:
                ratio = fuzz.ratio(keyword, name)
                if ratio > highest_ratio and ratio > 80:
                    highest_ratio = ratio
                    best_match = manufacturer
        
        return best_match if best_match else "Other"

    def scrape_contacts(self, url):
        """Scrape contact information from the dealership website."""
        if not url or pd.isna(url):
            return []
        
        contacts = []
        try:
            # Initialize Chrome driver
            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=self.chrome_options)
            driver.set_page_load_timeout(30)
            
            # Load the page
            driver.get(url)
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Get page source and parse with BeautifulSoup
            soup = BeautifulSoup(driver.page_source, 'html.parser')
            
            # Look for contact information
            contact_elements = soup.find_all(['a', 'p', 'div', 'span'], 
                text=re.compile(r'[\w\.-]+@[\w\.-]+\.\w+'))
            
            for element in contact_elements:
                email = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', element.text)
                if email:
                    contacts.append({
                        'type': 'email',
                        'value': email.group()
                    })
            
            # Look for phone numbers
            phone_elements = soup.find_all(['a', 'p', 'div', 'span'],
                text=re.compile(r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'))
            
            for element in phone_elements:
                phone = re.search(r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', element.text)
                if phone:
                    contacts.append({
                        'type': 'phone',
                        'value': phone.group()
                    })
            
            driver.quit()
            return contacts
        
        except Exception as e:
            logging.error(f"Error scraping contacts from {url}: {str(e)}")
            return []

    def process_batch(self, batch):
        """Process a batch of dealerships."""
        results = []
        for _, row in batch.iterrows():
            try:
                url = self.clean_url(row['Website'])
                is_active, final_url = self.verify_url(url)
                
                if is_active:
                    self.active_websites += 1
                    contacts = self.scrape_contacts(final_url)
                else:
                    contacts = []
                
                manufacturer = self.identify_manufacturer(row)
                self.manufacturer_counts[manufacturer] = self.manufacturer_counts.get(manufacturer, 0) + 1
                
                result = {
                    'DealershipName': row['DealershipName'],
                    'Website': url,
                    'IsActive': is_active,
                    'FinalURL': final_url if final_url else url,
                    'Manufacturer': manufacturer,
                    'Contacts': json.dumps(contacts),
                    'LastChecked': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                results.append(result)
                self.total_processed += 1
                
            except Exception as e:
                logging.error(f"Error processing dealership {row['DealershipName']}: {str(e)}")
                continue
        
        return results

    def process_dealerships(self):
        """Process all dealerships in the input file."""
        try:
            # Generate job ID if not exists
            if not self.job_id:
                self.job_id = str(int(time.time()))
            
            # Read input file
            df = pd.read_csv(self.input_file)
            total_dealerships = len(df)
            
            # Process in batches
            results = []
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = []
                for i in range(0, len(df), self.batch_size):
                    batch = df[i:i + self.batch_size]
                    futures.append(executor.submit(self.process_batch, batch))
                
                # Process completed batches
                for future in as_completed(futures):
                    batch_results = future.result()
                    results.extend(batch_results)
                    
                    # Save progress periodically
                    if len(results) % self.save_interval == 0:
                        self.save_intermediate_results(results)
                        self.save_progress()
            
            # Save final results
            self.save_final_results(results)
            
            # Log completion
            logging.info(f"Processing completed. "
                        f"Total processed: {self.total_processed}, "
                        f"Active websites: {self.active_websites}")
            
        except Exception as e:
            logging.error(f"Error in process_dealerships: {str(e)}")
            raise

    def save_intermediate_results(self, results):
        """Save intermediate results to CSV file."""
        df = pd.DataFrame(results)
        output_file = os.path.join(self.results_dir, f'verified_dealerships_{self.job_id}.csv')
        df.to_csv(output_file, index=False)

    def save_final_results(self, results):
        """Save final results and statistics."""
        # Save verified dealerships
        df = pd.DataFrame(results)
        output_file = os.path.join(self.results_dir, f'verified_dealerships_{self.job_id}.csv')
        df.to_csv(output_file, index=False)
        
        # Save statistics
        stats = {
            'total_processed': self.total_processed,
            'active_websites': self.active_websites,
            'manufacturer_distribution': self.manufacturer_counts,
            'completion_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'success_rate': round((self.active_websites / self.total_processed) * 100, 2) if self.total_processed > 0 else 0
        }
        
        stats_file = os.path.join(self.results_dir, f'verification_stats_{self.job_id}.json')
        with open(stats_file, 'w') as f:
            json.dump(stats, f, indent=2)

def main():
    parser = argparse.ArgumentParser(description='Verify dealership websites and extract contact information.')
    parser.add_argument('input_file', help='Path to the CSV file containing dealership data')
    parser.add_argument('--batch-size', type=int, default=50, help='Number of dealerships to process in each batch')
    parser.add_argument('--max-workers', type=int, default=4, help='Maximum number of concurrent workers')
    parser.add_argument('--save-interval', type=int, default=50, help='Save progress after processing this many dealerships')
    
    args = parser.parse_args()
    
    verifier = DealershipVerifier(
        input_file=args.input_file,
        batch_size=args.batch_size,
        max_workers=args.max_workers,
        save_interval=args.save_interval
    )
    
    verifier.process_dealerships()

if __name__ == '__main__':
    main() 