#!/usr/bin/env python3

from flask import Flask, render_template, request, jsonify, send_file, flash, redirect, url_for
import os
import pandas as pd
from datetime import datetime
import uuid
import json
import threading
import logging
from werkzeug.utils import secure_filename
from verify_all_dealerships import DealershipVerifier
from config import config

# Initialize Flask app with configuration
app = Flask(__name__)
app.config.from_object(config['production'])
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24))

# Configure logging for PythonAnywhere
log_dir = os.path.dirname(os.path.abspath(__file__))
log_file = os.path.join(log_dir, 'app.log')
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
)
logger = logging.getLogger(__name__)

# Initialize application directories
for directory in ['uploads', 'results']:
    dir_path = os.path.join(log_dir, directory)
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        logger.info(f'Created directory: {dir_path}')

# Constants
ALLOWED_EXTENSIONS = {'csv'}
UPLOADS_FOLDER = os.path.join(log_dir, 'uploads')
RESULTS_FOLDER = os.path.join(log_dir, 'results')
JOBS_FILE = os.path.join(log_dir, 'jobs.json')

# Job persistence functions
def load_jobs():
    try:
        if os.path.exists(app.config['JOBS_FILE']):
            with open(app.config['JOBS_FILE'], 'r') as f:
                data = json.load(f)
                return data.get('jobs', {}), data.get('active_jobs', {})
        return {}, {}
    except Exception as e:
        logger.error(f'Failed to load jobs: {e}')
        return {}, {}

def save_jobs():
    try:
        with open(app.config['JOBS_FILE'], 'w') as f:
            json.dump({'jobs': jobs, 'active_jobs': active_jobs}, f)
    except Exception as e:
        logger.error(f'Failed to save jobs: {e}')

def update_job_progress(job_id, progress, status_msg=''):
    try:
        if job_id in active_jobs:
            active_jobs[job_id]['progress'] = progress
            if status_msg:
                active_jobs[job_id]['status_message'] = status_msg
            save_jobs()
    except Exception as e:
        logger.error(f'Failed to update job progress: {e}')

# Load saved jobs on startup
jobs, active_jobs = load_jobs()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_dealerships(job_id, input_file, max_websites=0):
    try:
        # Initialize verifier with PythonAnywhere-optimized settings
        verifier = DealershipVerifier(
            batch_size=app.config['BATCH_SIZE'],
            max_workers=app.config['MAX_WORKERS'],
            save_interval=app.config['SAVE_INTERVAL']
        )
        
        # Read input file
        df = pd.read_csv(input_file)
        if max_websites > 0:
            df = df.head(max_websites)
        
        # Set up output files
        job_folder = os.path.join(RESULTS_FOLDER, job_id)
        os.makedirs(job_folder, exist_ok=True)
        
        verified_file = os.path.join(job_folder, 'verified_dealerships.csv')
        contacts_file = os.path.join(job_folder, 'dealership_contacts.csv')
        stats_file = os.path.join(job_folder, 'verification_stats.json')
        log_file = os.path.join(job_folder, 'job.log')
        
        # Process dealerships
        verifier.verify_dealerships(input_file, scrape_contacts=True)
        
        # Move results to job folder with error handling
        for src, dst in [
            ('verified_dealerships.csv', verified_file),
            ('dealership_contacts.csv', contacts_file),
            ('verification_stats.json', stats_file),
            ('dealership_verification.log', log_file)
        ]:
            try:
                if os.path.exists(src):
                    os.rename(src, dst)
                    logger.info(f'Successfully moved {src} to {dst}')
            except Exception as e:
                logger.error(f'Failed to move {src} to {dst}: {e}')
                # Try to copy if rename fails
                try:
                    import shutil
                    shutil.copy2(src, dst)
                    os.remove(src)
                    logger.info(f'Successfully copied {src} to {dst} as fallback')
                except Exception as copy_error:
                    logger.error(f'Failed to copy {src} to {dst}: {copy_error}')
        
        # Update job status
        jobs[job_id] = {
            'id': job_id,
            'filename': os.path.basename(input_file),
            'status': 'completed',
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'dealership_count': len(df),
            'contact_count': len(pd.read_csv(contacts_file)) if os.path.exists(contacts_file) else 0
        }
        
    except Exception as e:
        # Log error and update job status
        with open(os.path.join(job_folder, 'error.log'), 'w') as f:
            f.write(str(e))
        jobs[job_id] = {
            'id': job_id,
            'filename': os.path.basename(input_file),
            'status': 'failed',
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'error': str(e)
        }
    
    finally:
        # Remove from active jobs
        if job_id in active_jobs:
            del active_jobs[job_id]

@app.route('/')
def index():
    recent_jobs = []
    for job_id, job in active_jobs.items():
        recent_jobs.append({
            'id': job_id,
            'status': job['status'],
            'processed': job.get('processed', 0),
            'active_urls': job.get('active_urls', 0)
        })
    return render_template('index.html', active_jobs=active_jobs, recent_jobs=recent_jobs)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file selected', 'danger')
        return redirect(url_for('index'))
    
    file = request.files['file']
    if file.filename == '':
        flash('No file selected', 'danger')
        return redirect(url_for('index'))
    
    if not allowed_file(file.filename):
        flash('Invalid file type. Please upload a CSV file.', 'danger')
        return redirect(url_for('index'))
    
    try:
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOADS_FOLDER, filename)
        file.save(filepath)
        
        # Create job ID and initialize job status
        job_id = str(uuid.uuid4())
        batch_size = int(request.form.get('batch_size', 50))
        
        active_jobs[job_id] = {
            'status': 'Processing',
            'progress': 0,
            'filename': filename,
            'filepath': filepath,
            'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Initialize DealershipVerifier
        verifier = DealershipVerifier(
            input_file=filepath,
            batch_size=batch_size,
            max_workers=4,
            save_interval=batch_size
        )
        
        # Start processing in a background thread
        verifier.process_dealerships()
        
        flash('File uploaded successfully. Processing started.', 'success')
        return redirect(url_for('index'))
    
    except Exception as e:
        logging.error(f"Error processing upload: {str(e)}")
        flash(f'Error processing file: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/verify_single_url', methods=['POST'])
def verify_single_url():
    url = request.form.get('url')
    dealership_name = request.form.get('dealership_name')
    
    if not url or not dealership_name:
        flash('Please provide both URL and dealership name', 'danger')
        return redirect(url_for('index'))
    
    try:
        # Create a single-row DataFrame
        df = pd.DataFrame([{
            'Website': url,
            'DealershipName': dealership_name
        }])
        
        # Save temporary CSV
        temp_file = os.path.join(UPLOADS_FOLDER, f'single_url_{uuid.uuid4()}.csv')
        df.to_csv(temp_file, index=False)
        
        # Create job ID and initialize status
        job_id = str(uuid.uuid4())
        active_jobs[job_id] = {
            'status': 'Processing',
            'progress': 0,
            'filename': 'single_url.csv',
            'filepath': temp_file,
            'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Initialize verifier and process
        verifier = DealershipVerifier(
            input_file=temp_file,
            batch_size=1,
            max_workers=1,
            save_interval=1
        )
        
        verifier.process_dealerships()
        
        flash('URL verification started', 'success')
        return redirect(url_for('index'))
    
    except Exception as e:
        logging.error(f"Error processing single URL: {str(e)}")
        flash(f'Error processing URL: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/job_status/<job_id>')
def job_status(job_id):
    if job_id not in active_jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = active_jobs[job_id]
    return jsonify({
        'status': job['status'],
        'progress': job['progress']
    })

@app.route('/view_results/<job_id>')
def view_results(job_id):
    try:
        # Load results
        results_file = os.path.join(RESULTS_FOLDER, f'verified_dealerships_{job_id}.csv')
        df = pd.read_csv(results_file)
        
        # Prepare results for template
        results = []
        for _, row in df.iterrows():
            results.append({
                'dealership_name': row['DealershipName'],
                'url': row['Website'],
                'is_active': row['IsActive'],
                'manufacturer': row['Manufacturer'],
                'contacts_found': len(json.loads(row['Contacts'])) if 'Contacts' in row else 0,
                'last_checked': row['LastChecked']
            })
        
        # Calculate statistics
        stats = {
            'total_records': len(df),
            'active_websites': df['IsActive'].sum(),
            'manufacturer_count': df['Manufacturer'].nunique()
        }
        
        # Calculate manufacturer statistics
        manufacturer_stats = []
        for mfr in df['Manufacturer'].unique():
            mfr_df = df[df['Manufacturer'] == mfr]
            manufacturer_stats.append({
                'name': mfr,
                'count': len(mfr_df),
                'active_urls': mfr_df['IsActive'].sum(),
                'success_rate': round((mfr_df['IsActive'].sum() / len(mfr_df)) * 100, 1)
            })
        
        return render_template('view_data.html',
                             job_id=job_id,
                             results=results,
                             stats=stats,
                             manufacturer_stats=manufacturer_stats)
    
    except Exception as e:
        logging.error(f"Error viewing results: {str(e)}")
        flash(f'Error viewing results: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/download_results/<job_id>')
def download_results(job_id):
    try:
        results_file = os.path.join(RESULTS_FOLDER, f'verified_dealerships_{job_id}.csv')
        return send_file(results_file,
                        mimetype='text/csv',
                        as_attachment=True,
                        download_name='verified_dealerships.csv')
    except Exception as e:
        logging.error(f"Error downloading results: {str(e)}")
        flash(f'Error downloading results: {str(e)}', 'danger')
        return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0') 